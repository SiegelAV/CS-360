package com.zybooks.austin_siegel_project_2_new;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class HomePageActivity extends AppCompatActivity {

    private GridView gridView;
    private List<String> eventsList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_homepage_activity);

        // Initialize views
        gridView = findViewById(R.id.calendar_gridview);
        FloatingActionButton fab = findViewById(R.id.add_event_fab);

        // Initialize list to store events
        eventsList = new ArrayList<>();

        // Initialize adapter for grid view
        adapter = new ArrayAdapter<String>(this, R.layout.expanded_activity, R.id.event_text, eventsList) {
            @Override
            public View getView(final int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = view.findViewById(R.id.event_text);
                textView.setText(eventsList.get(position));

                Button editButton = view.findViewById(R.id.edit_button);
                editButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Handle edit button click, for now, let's just show a toast
                        Toast.makeText(HomePageActivity.this, "Edit clicked for position: " + position, Toast.LENGTH_SHORT).show();
                    }
                });

                editButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        goToExpandedActivity();
                    }
                });

                Button deleteButton = view.findViewById(R.id.delete_button);
                deleteButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        deleteEvent(position);
                    }
                });
                return view;




            }
        };
        gridView.setAdapter(adapter);

        // Set click listener for floating action button
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add event to list and update adapter
                addEvent();
            }
        });

        // Set item click listener for grid view (optional)
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Handle item click event if needed
                String event = adapter.getItem(position);
                Toast.makeText(HomePageActivity.this, "Clicked on: " + event, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addEvent() {
        // For demonstration purpose, adding a dummy event
        String newEvent = "New Event " + (eventsList.size() + 1);
        eventsList.add(newEvent);
        adapter.notifyDataSetChanged();
        Toast.makeText(this, "Event added: " + newEvent, Toast.LENGTH_SHORT).show();
    }

    private void deleteEvent(int position) {
        String deletedEvent = eventsList.remove(position);
        adapter.notifyDataSetChanged();
        Toast.makeText(this, "Deleted Event: " + deletedEvent, Toast.LENGTH_SHORT).show();
    }

    private void goToExpandedActivity() {
        Intent intent = new Intent(HomePageActivity.this, expanded_activity.class);
        startActivity(intent);
        // You may or may not finish the current activity based on your navigation flow
    }


}