package com.zybooks.austin_siegel_week_3_assignment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nameText;
    private Button buttonSayHello;
    private TextView textGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameText = findViewById(R.id.nameText);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);

        // Add a TextWatcher to dynamically enable/disable the button
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Enable the button if there is text in nameText, disable otherwise
                buttonSayHello.setEnabled(!charSequence.toString().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
    }

    // Define the SayHello function
    public void SayHello(View view) {
        String name = nameText.getText().toString();

        // Check if name is not null or empty
        if (!name.isEmpty()) {
            // Display greeting with the entered name
            textGreeting.setText("Hello " + name);
        } else {
            // Display an error message if name is null or empty
            textGreeting.setText("You must enter a name");
        }
    }
}